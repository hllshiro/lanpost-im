# 内网通私有协议：命令号 / XML 元素目标清单

> 用途：Phase 2 静态逆向产出，给后续实时抓包（Phase 4）提供"盯什么"的靶标清单。
>
> **可信度约定**：只有第 1 节（来自 `nwt-private-protocol.md` 规格，已被真实客户端联调验证）算"已确认"。第 2、3 节全部是**静态推断**，逐条标注置信度，**未抓包前一律按待验证处理**。
>
> 分析对象：`D:/Program Files (x86)/nwt/Nwt/ShiYeLine.exe`（7,416,176 字节，PE32 i386，内网通 3.4.3055）。
> 本次分析**没有**运行任何内网通进程，也没有抓包，结论全部来自二进制静态分析。
>
> **⚠ 2026-11-12 更新**：本文 §2.3 / §2.4 里 1026–1064 的"候选命令"已被证伪。真实私有命令空间是 4 段
> （`1000–1025`、`3000–3012` 群组、`4000–4001` 远程、`5000–5009` 共享文件柜），共 51 条，全部映射到模板。
> 命令号与模板的权威结论以 [nwt-command-map.md](nwt-command-map.md) 为准；本文保留作为第一轮过程记录。

---

## 0. 本次分析最重要的三个结论

1. **私有文字通道的命令号空间是 1000–1064，不存在 2000–3999 的命令号。**
   原计划里"重点关注 2000–3999"的假设被证伪：全二进制 `.text` 中出现的 2000/3000 段字面量共 81 个，全部是普通常量（`2048` 缓冲区、`2000` 毫秒超时、`3000`/`3600` 尺寸与秒数等），没有一个进入私有通道的发送函数。详见 §2.5。

2. **找到并验证了发送汇聚点**：49 个 `push <命令号>` 站点全部紧跟着 `call` 同一个/同一组发送函数，其中包含规格里已确认的 8 个命令。这是命令号清单的**强证据源**（不是字符串猜测）。

3. **`.rdata` 中存在 50 条完整的 XML 模板字符串**（`<X_XXX docver="%u">...`），以及 RTTI 里 55 个 `*Packer` 类名。
   这两组数据把"未知协议"变成了"已知字段表"：模板里每个元素的类型（`%u` / `%llu` / `%s`）都写在格式串里。

---

## 1. 已确认命令号（来源：`docs/04-参考资料/nwt-private-protocol.md`）

| 命令号 | 名称 | 方向 | 说明 | 状态 |
|---:|---|---|---|---|
| 4 | hello | 双向 | 304 字节明文报文，结构同 9011 发现报文，不走应用帧加密 | 已确认 |
| 1000 | X_HANDSHARK | 双向 | 能力位 + 个人资料 + 端口 | 已确认 |
| 1004 | X_SEND_MSG | 双向 | 文字，`<MSG>` 内是 JSON | 已确认 |
| 1005 | X_SEND_MSG_ACK | 收→发 | 送达确认，带 `MSG_ID` | 已确认 |
| 1006 | X_SEND_RECEIPT | 收→发 | 已读回执，带 `MSG_ID` | 已确认 |
| 1008 | X_SEND_WRITTING | 双向 | 正在输入 | 已确认 |
| 1016 | X_HEARTBEAT | 双向 | 心跳，`<X_HEARTBEAT docver="1" />` | 已确认 |
| 1017 | X_QUIT | 双向 | 退出 | 已确认 |
| 1018 | X_READY | 双向 | `USER_ID` 为本机 32 位十六进制标识 | 已确认 |

应用帧格式（已确认，供对照）：

```
u32 总长（大端，= 8 + 正文字节数）
u32 命令号（大端）
正文（UTF-8 XML，TEA 密文，密钥 "8asfhj@k7*20hbla"）
```

---

## 2. 候选命令号

### 2.1 数据来源：49 个发送桩

代码里每个私有命令都有一个独立的发送桩函数，形状固定：

```asm
push <命令号>          ; 68 xx xx 00 00
mov  ecx, [ebp+xx]     ; this
call <发送函数>        ; 本次命中 0x793140 / 0x883f68
```

其中 `<命令号>` 是**紧邻 `call` 的 `push imm32`**。这套模式在已知的 1005/1006/1008/1016/1017 上全部命中，因此可以当作可靠的地基。

49 个桩的地址还天然分块，同一块基本对应同一个功能模块（下表的"桩地址"列）。

### 2.2 已定位到 XML 模板的命令（置信度：高 / 中）

判定依据：模板字符串引用点之后 < 600 字节内出现 `push <命令号>`，且其后 60 字节内存在对发送函数的 `call`。
`d=` 是该 `push` 距模板引用的字节距离。

| 命令号 | 推测用途 | 证据（字符串 / 上下文） | 置信度 |
|---:|---|---|---|
| 1000 | 握手（能力位 + 资料 + 端口） | `<X_HANDSHARK ...>`，d=557，后接发送 call | 高（与规格一致） |
| 1001 | 修改在线状态 | `<X_CHANGE_STATUS docver="%u"><STATUS>%u</STATUS>`，d=31，直接验证过汇编窗口 | 高 |
| 1002 | 修改签名 | `<X_CHANGE_SIGN docver="%u"><SIGN>%s</SIGN>`，d=88 | 高 |
| 1003 | 修改个人资料 | `<X_CHANGE_INFO ...>`（含 NAME/GROUP/DEPARTMENT/TEL/MOBILE/EMAIL/SIGN/USER_FACE…），d=476 | 高 |
| 1004 | 文字消息 | `<X_SEND_MSG docver="%u"><MSG_ID>%llu</MSG_ID><RECEIPT>%u</RECEIPT><MSG>%s</MSG><MSG_TIME>%llu</MSG_TIME><OFFLINE>%u</OFFLINE><HIDE_RECORD>%u</HIDE_RECORD>`，d=91 | 高（与规格一致） |
| 1005 | 送达确认 | `<X_SEND_MSG_ACK docver="%u"><MSG_ID>%llu</MSG_ID>`，d=31 | 高（与规格一致） |
| 1006 | 已读回执 | `<X_SEND_RECEIPT docver="%u"><MSG_ID>%llu</MSG_ID>`，d=31 | 高（与规格一致） |
| 1007 | 闪屏 / 抖动 | `<X_SEND_FLASH_SCREEN docver="%u"><TYPE>%u</TYPE>`，d=31，汇编窗口直接验证（`push 0x3ef`=1007） | 高 |
| 1008 | 正在输入 | `<X_SEND_WRITTING docver="%u"><TYPE>%u</TYPE>`，d=31 | 高（与规格一致） |
| 1009 | 发送文件请求 | `<X_SEND_FILE docver="%u"><TASK_ID>%llu</TASK_ID><FILE_ID>%llu</FILE_ID><NAME>%s</NAME><PWD>%s</PWD><SIZE>%llu</SIZE><LAST_MODIFY>%llu</LAST_MODIFY><OFFLINE>%u</OFFLINE>`，d=141 | 高 |
| 1010 | 文件发送操作（暂停/取消/继续） | `<X_OPERATE_SEND_FILE docver="%u"><TASK_ID>%llu</TASK_ID><OP>%u</OP>`，d=35 | 高 |
| 1011 | 文件接收操作 | `<X_OPERATE_RECV_FILE docver="%u"><TASK_ID>%llu</TASK_ID><OP>%u</OP>`，d=35 | 高 |
| 1012 | 文件接收进度 | `<X_PROGRESS_RECV_FILE docver="%u"><TASK_ID>%llu</TASK_ID><TOTAL_SIZE>%llu</TOTAL_SIZE><RECVD_SIZE>%llu</RECVD_SIZE><SPEED>%s</SPEED>`，d=57 | 中 |
| 1013 | 发送文件夹请求 | `<X_SEND_FOLDER docver="%u"><TASK_ID>%s</TASK_ID><FOLDER_NAME>%s</FOLDER_NAME><FOLDER_SIZE>%llu</FOLDER_SIZE><MAX_ITEM_PATH>%llu</MAX_ITEM_PATH><MAX_ITEM_SIZE>%llu</MAX_ITEM_SIZE><OFFLINE>%u</OFFLINE>`，d=163 | 高 |
| 1014 | 文件夹发送操作 | `<X_OPERATE_SEND_FOLDER docver="%u"><TASK_ID>%s</TASK_ID><OP>%u</OP>`，d=104 | 中 |
| 1015 | 文件夹接收操作 | `<X_OPERATE_RECV_FOLDER docver="%u"><TASK_ID>%s</TASK_ID><OP>%u</OP>`，d=104 | 中 |
| 1016 | 心跳 | `<X_HEARTBEAT docver="%u" />`，d=31 | 高（与规格一致） |
| 1017 | 退出 | `<X_QUIT docver="%u" />`，d=31 | 高（与规格一致） |
| 1018 | 就绪 | `<X_READY docver="%u"><USER_ID>%s</USER_ID><PARAM>%u</PARAM>`，d=109 | 高（与规格一致） |
| 1019 | 反向（拉取）文件请求 | `<X_REVERSE_FILE_REQ docver="%u"><TASK_ID>%llu</TASK_ID>`，d=90 | 中 |
| 1020 | 反向（拉取）文件夹请求 | `<X_REVERSE_FOLDER_REQ docver="%u"><TASK_ID>%s</TASK_ID>`，d=87 | 中 |
| 1021 | 共享目录 / 网段查询 | `<X_SHARE_SUBNET docver="%u"><SUBNETS>…`，d=451，后接发送 call | 低 |
| 1022 | 离线消息发送完成 | `<X_OFFLINE_SEND_COMPLETED docver="%u"><TYPE>%u</TYPE>`，d=31 | 高 |
| 1023 | 离线消息删除 | `<X_OFFLINE_DELETE docver="%u"><TYPE>%u</TYPE>`，d=31 | 高 |
| 1024 | 提醒文件（按组号） | `<X_REMIND_FILE docver="%u"><GROUP>%u</GROUP><FILE>%u</FILE><FILE_SIZE>%llu</FILE_SIZE><FILE_NAME>%s</FILE_NAME>`，d=88 | 中 |
| 1025 | 提醒文件（按 GROUP_ID） | `<X_REMIND_FILE docver="%u"><GROUP_ID>%s</GROUP_ID><FILE>%u</FILE>…` | 中 |

**内部一致性佐证**：1009–1015 正好是一整个"文件/文件夹传输"连续块，1016/1017/1018 又精确对上规格里的心跳/退出/就绪，说明这条编号不是猜出来的，而是同一份枚举。

### 2.3 已定位"存在但未定位模板"的命令（置信度：中 / 低）

这 17 个命令号有确凿的发送桩（因此**确实存在于协议里**），但静态分析没能把模板绑上去——这些桩所属的构建函数很大（1–3 KB），命令号 `push` 离模板引用超过 1 KB，启发式窗口覆盖不到。

| 命令号 | 推测用途 | 证据（字符串 / 上下文） | 置信度 |
|---:|---|---|---|
| 1026 | 未知（文件/离线块内） | 桩 0x848800，与 1024/1025/1027 同块 | 低 |
| 1027 | 未知（文件/离线块内） | 桩 0x848a20，同块 | 低 |
| 1029 | 群组相关（猜测） | 桩 0x848c70，同块 | 低 |
| 1030 | 群组相关（猜测） | 桩 0x848ec0 | 低 |
| 1031 | 群组相关（猜测） | 桩 0x849110 | 低 |
| 1032 | 群组相关（猜测） | 桩 0x8492f0 | 低 |
| 1033 | QGROUP 群组消息 | 桩 0x878060；1033–1043 是独立的连续块，而 `.rdata` 里 QGROUP 模板有 13 条 | 中 |
| 1034 | QGROUP 群组消息 | 桩 0x8781f0，同块 | 中 |
| 1035 | QGROUP 群组消息 | 桩 0x878320，同块 | 中 |
| 1036 | QGROUP 群组消息 | 桩 0x878430，同块 | 中 |
| 1040 | QGROUP 群组消息 | 桩 0x878580，同块 | 中 |
| 1041 | QGROUP 群组消息 | 桩 0x878690，同块 | 中 |
| 1042 | QGROUP 群组消息 | 桩 0x8787b0，同块 | 中 |
| 1043 | QGROUP 群组消息 | 桩 0x8788b0，同块 | 中 |
| 1051 | 共享文件柜（猜测） | 桩 0x805020；1051–1058 是独立连续块，SHARE 模板有 15 条 | 中 |
| 1052 | 共享文件柜（猜测） | 桩 0x805160，同块 | 中 |
| 1053 | 共享文件柜（猜测） | 桩 0x8052c0，同块 | 中 |
| 1054 | 共享文件柜（猜测） | 桩 0x805440，同块 | 中 |
| 1055 | 共享文件柜（猜测） | 桩 0x805590，同块 | 中 |
| 1056 | 共享文件柜（猜测） | 桩 0x8056f0，同块 | 中 |
| 1057 | 共享文件柜（猜测） | 桩 0x8059a0，同块 | 中 |
| 1058 | 共享文件柜（猜测） | 桩 0x805b60，同块 | 中 |
| 1064 | 远程协助（猜测） | 桩 0x7f9e20，孤立单桩；`X_REMOTE_REQUEST` / `X_REMOTE_OPERATE` 至今没有对应命令号 | 低 |

### 2.4 命令号枚举里的"缺口"（中）

以下值在 1000–1064 区间内、但**没有发送桩**，说明本版本只收不发，或功能未接线：

```
1028  1037  1038  1039  1044  1045  1046  1047  1048  1049  1050  1059  1060  1061  1062  1063
```

抓包时如果对端发来这些号，本客户端大概率忽略或走"未知命令"分支——反过来这也是个验证点。

### 2.5 为什么说"不存在 2000–3999 的命令号"

对 `.text` 全段做 `push imm32` 扫描，统计落在 2000–3999 的字面量：共 81 个不同取值。抽样验证上下文全是普通常量：

- `2048`（出现 23 次）——缓冲区/栈大小
- `2000`（91 次）——毫秒超时
- `3000` / `3600` / `3584` / `3824`–`3840`——尺寸与秒数
- `2202`/`2204`/`2101`/`2106`——多为窗口消息或长度

它们没有任何一个出现在"紧邻发送函数 call"的位置（而 1000–1064 的 49 个全部满足该条件）。

**唯一的结构化 2000+/3000+ 簇**：另一个汇聚点 `0x67b3b0` 同时收到 `1000–1025` 与 `3000–3012`、`4000–4001`、`5000–5009`。因为它和私有命令号混在一起，判断它**不是协议命令分发**，更可能是"内部消息/日志记录"函数，参数空间跨了多个枚举。**待验证**，抓包时不必为 3000/4000/5000 段预留注意力。

---

## 3. 提取到的 XML 元素名（按疑似功能分组）

全部 50 条模板原文见脚本产物 `out/templates.txt`。以下按模板名归组，标注元素与类型。

### 3.1 握手与个人资料（1000 / 1001 / 1002 / 1003 / 1018）

`X_HANDSHARK` 的结构最有价值，等于把能力协商表直接交出来了：

```
<FEATURE>  MAJOR MINOR BUILD APP MSG FILE_TRAN FOLDER_TRAN REMOTE_ASSISTANCE
           FILE_SHARE QGROUP QGROUP_MSG QGROUP_FILE QGROUP_FOLDER
           OFFLINE_MSG OFFLINE_FILE LAN_UPDATE HIDE_RECORD
<INFO>     CORP_ID CORP_TIME NAME GROUP CORPORATION DEPARTMENT SEX POST TEL
           MOBILE EMAIL SIGN SYS_FACE USER_FACE[id] STATUS ACTIVE_SEND
           ONLINE_POPUP HIDE_IP COLOR_NAME SORT_NAME DECORATE_NAME
<NET>      FILE_TRAN_TCP_PORT FILE_TRAN_ENET_PORT
           FOLDER_TRAN_TCP_PORT FOLDER_TRAN_ENET_PORT
           FILE_TRAN_TCP_REVERSE_PORT FILE_TRAN_ENET_REVERSE_PORT
           FOLDER_TRAN_TCP_REVERSE_PORT FOLDER_TRAN_ENET_REVERSE_PORT
           LAN_UPDATE_HTTP_PORT
```

> `FEATURE` 子项全为 `%s`（不是 `%u`），说明传的是字符串化的值（如 `"2:1"`），与规格里 `MSG=2:1` 的写法一致。

其余：
- `X_CHANGE_INFO`：`NAME GROUP CORPORATION DEPARTMENT SEX POST TEL MOBILE EMAIL SIGN SYS_FACE USER_FACE[id] STATUS ACTIVE_SEND ONLINE_POPUP HIDE_IP COLOR_NAME SORT_NAME DECORATE_NAME"`
- `X_CHANGE_SIGN`：`SIGN`
- `X_CHANGE_STATUS`：`STATUS`（`%u`）
- `X_READY`：`USER_ID`（`%s`）、`PARAM`（`%u`）

### 3.2 文字消息（1004 / 1005 / 1006 / 1008）

- `X_SEND_MSG`：`MSG_ID`(`%llu`) `RECEIPT`(`%u`) `MSG`(`%s`) `MSG_TIME`(`%llu`) `OFFLINE`(`%u`) `HIDE_RECORD`(`%u`)
- `X_SEND_MSG_ACK`：`MSG_ID`(`%llu`)
- `X_SEND_RECEIPT`：`MSG_ID`(`%llu`)
- `X_SEND_WRITTING`：`TYPE`(`%u`)

> 规格里说发送方固定写 `RECEIPT=0 / MSG_TIME=0 / OFFLINE=0 / HIDE_RECORD=0`——模板证实这四个字段确实存在，且 `MSG_TIME` 是 `%llu`（毫秒时间戳）。

### 3.3 心跳 / 退出（1016 / 1017）

- `X_HEARTBEAT docver="%u" />`（自闭合，与规格的 26 字节明文一致）
- `X_QUIT docver="%u" />`

### 3.4 文件与文件夹传输（1009–1015、1019、1020、1024、1025）

| 模板 | 元素 |
|---|---|
| `X_SEND_FILE` | `TASK_ID`(`%llu`) `FILE_ID`(`%llu`) `NAME` `PWD` `SIZE`(`%llu`) `LAST_MODIFY`(`%llu`) `OFFLINE`(`%u`) |
| `X_SEND_FOLDER` | `TASK_ID`(`%s`!) `FOLDER_NAME` `FOLDER_SIZE` `MAX_ITEM_PATH` `MAX_ITEM_SIZE` `OFFLINE` |
| `X_OPERATE_SEND_FILE` | `TASK_ID`(`%llu`) `OP`(`%u`) |
| `X_OPERATE_RECV_FILE` | `TASK_ID`(`%llu`) `OP`(`%u`) |
| `X_OPERATE_SEND_FOLDER` | `TASK_ID`(`%s`) `OP`(`%u`) |
| `X_OPERATE_RECV_FOLDER` | `TASK_ID`(`%s`) `OP`(`%u`) |
| `X_PROGRESS_RECV_FILE` | `TASK_ID`(`%llu`) `TOTAL_SIZE` `RECVD_SIZE` `SPEED`(`%s`) |
| `X_REVERSE_FILE_REQ` | `TASK_ID`(`%llu`) |
| `X_REVERSE_FOLDER_REQ` | `TASK_ID`(`%s`) |
| `X_REMIND_FILE` | `GROUP`(`%u`) `FILE`(`%u`) `FILE_SIZE`(`%llu`) `FILE_NAME` / 或 `GROUP_ID`(`%s`) 变体 |

> 注意 **`TASK_ID` 有两种类型**：文件和 `%llu`，文件夹和 `%s`。这是实现时必须分流的硬约束，抓包时要专门确认。

### 3.5 离线消息（1022 / 1023）

- `X_OFFLINE_SEND_COMPLETED`：`TYPE`(`%u`)
- `X_OFFLINE_DELETE`：`TYPE`(`%u`)

> 只有两个字段极少的命令，配合 `X_SEND_MSG` / `X_SEND_FILE` 里的 `OFFLINE`(`%u`) 标志位，可以推断离线队列是"带 OFFLINE 标志正常发 + 发完通告 + 删除"三段式。**待验证**。

### 3.6 群组 QGROUP（疑 1033–1043）

公共子结构 `QG`（在 INVITE / PUSH_INFO / PUSH_USER 里重复出现）：

```
INFO: QGROUP_ID QGROUP_NAME QGROUP_MASTER QGROUP_INTR QGROUP_ANN
      QGROUP_INFO_VER QGROUP_USER_VER QGROUP_ALLOW_OTHER_ADD QGROUP_PHOTO_MD5
```

> **模板 bug 线索**：原文写的是 `<QGROUP_INFO_VER>%llu</GROUP_INFO_VER>`——闭合标签少了 `Q` 前缀。真实 XML 解析器可能容忍，也可能这是"只用于 sprintf 生成、从不用解析器校验"的证据。抓包时应核对该标签的真实拼写。

| 模板 | 关键元素 |
|---|---|
| `X_QGROUP_INVITE` / `X_QGROUP_PUSH_INFO` | `<INFO>` 全套 |
| `X_QGROUP_PUSH_USER` | `<INFO>` + `USER` |
| `X_QGROUP_INVITE_RSP` | `QGROUP_ID` `USER_NAME` `ACTION`(`%u`) |
| `X_QGROUP_OTHER_INVITE` | `QGROUP_ID` `USER` |
| `X_QGROUP_REQ_INFO` / `X_QGROUP_REQ_USER` | `QGROUP_ID` |
| `X_QGROUP_REQ_INFO_RSP` / `X_QGROUP_REQ_USER_RSP` | `RET`(`%u`) `QGROUP_ID`（+ `INFO` 或 `INFO`+`USER` 变体） |
| `X_QGROUP_SEND_MSG` | `QGROUP_ID` `MSG_ID`(`%llu`) `MSG`(`%s`) `HIDE_RECORD`(`%u`) |
| `X_QGROUP_DISMISS` / `X_QGROUP_EXIT` / `X_QGROUP_KICK` | `QGROUP_ID` |

### 3.7 共享文件柜 SHARE（疑 1051–1058）

统一请求头：`REQ_ID`(`%llu`) `SHARE_ID`(`%s`) `SHARE_PATH`(`%s`) `SHARE_PWD`(`%s`)，响应统一带 `ERR`(`%u`)。

| 模板 | 关键元素 |
|---|---|
| `X_SHARE_SUBNET` | `SUBNETS`（外层，见 §3.9） |
| `X_SHARE_GET_REMOTE_ROOT` | `REQ_ID` |
| `X_SHARE_GET_REMOTE_ROOT_RSP` | `ERR` `END` `REQ_ID` |
| `X_SHARE_GET_REMOTE` | `REQ_ID` `SHARE_ID` `SHARE_PATH` `SHARE_PWD` `CHECK_PWD` |
| `X_SHARE_GET_REMOTE_RSP` | `ERR` `END` `REQ_ID` `SHARE_ID` `SHARE_PATH` + `CATALOG_ITEM` 分页 |
| `X_SHARE_CHECK_PWD` | `REQ_ID` `SHARE_ID` `SHARE_PATH` `SHARE_PWD` |
| `X_SHARE_CHECK_PWD_RSP` | `ERR` `REQ_ID` `FILE_ID` |
| `X_SHARE_DOWNLOAD_FILE` | 请求头 + `CHECK_PWD` `GO_ON` |
| `X_SHARE_DOWNLOAD_FILE_RSP` | `ERR` `REQ_ID` `FILE_ID` `FILE_SIZE` `LAST_MODIFY` |
| `X_SHARE_DOWNLOAD_FOLDER` | 请求头 + `CHANNEL_ID` `CHECK_PWD` `GO_ON` |
| `X_SHARE_DOWNLOAD_FOLDER_RSP` | `ERR` `REQ_ID` `CHANNEL_ID` |

分页目录项 `CATALOG_ITEM`（独立字符串，0x5ed33c）配合 `END`(`%u`) 做分页终止标记。

### 3.8 远程协助与杂项

- `X_REMOTE_REQUEST`：`REQ`(`%u`) `PWD`(`%s`)
- `X_REMOTE_OPERATE`：`OP`(`%u`) `PARAM`(`%u`)
- `X_SEND_FLASH_SCREEN`：`TYPE`(`%u`)（命令号 1007）

### 3.9 协议外层字符串（非 `X_` 前缀，容易漏）

| 偏移 | 字符串 | 用途推断 |
|---|---|---|
| 0x5bd240 | `<ShiYeLine docver="1"><SubnetIps>` | 网段/子网清单外层 |
| 0x5bd274 | `</SubnetIps></ShiYeLine>` | 同上闭合 |
| 0x5e00e0 | `%u@shiyeline:%u:%s:%s:%u:%s` | IPMSG 扩展身份后缀（对应飞秋的 `1_lbt80_0#...#9:`） |
| 0x5e0128 | `@shiyeline` | 身份后缀的固定片段 |
| 0x5e1624 | `<InstallCfg docver="1.0">` | 安装配置，与协议无关 |
| 0x5ed33c | `CATALOG_ITEM` | 共享目录分页项 |

### 3.10 全量 `*Packer` 类（RTTI，消息清单交叉验证）

`ShiYeLine.exe` 保留完整 RTTI，`*Packer` 后缀的类基本等价于"每个协议消息一个序列化器"：

```
CChangeInfoPacker CChangeSignPacker CChangeStatusPacker CEmptyPacker
CFileReverseReqPacker CFolderReverseReqPacker CHandsharkPacker
CHeartbeatPacker COfflineDeletePacker COfflinePacker
COfflineSendCompletedPacker COnlinePacker COperateRecvFilePacker
COperateRecvFolderPacker COperateSendFilePacker COperateSendFolderPacker
CPacker CProgressRecvFilePacker CQuitPacker CReadyPacker
CRemindFilePacker CRemoteOperatePacker CRemoteRequestPacker
CSendFilePacker CSendFlashScreenPacker CSendFolderPacker
CSendMsgAckPacker CSendMsgPacker CSendReceiptPacker CSendWrittingPacker
CQGroupDismissPacker CQGroupExitPacker CQGroupInvitePacker
CQGroupInviteRspPacker CQGroupKickPacker CQGroupOtherInvitePacker
CQGroupPushInfoPacker CQGroupPushUserPacker CQGroupRemindFilePacker
CQGroupReqInfoPacker CQGroupReqInfoRspPacker CQGroupReqUserPacker
CQGroupReqUserRspPacker CQGroupSendMsgPacker
CShareCheckPwdPacker CShareCheckPwdRspPacker CShareDownloadFilePacker
CShareDownloadFileRspPacker CShareDownloadFolderPacker
CShareDownloadFolderRspPacker CShareGetRemotePacker
CShareGetRemoteRootPacker CShareGetRemoteRootRspPacker
CShareGetRemoteRspPacker CShareSubnetPacker
```

注意出现了两个没有对应 `X_` 模板的类：**`COnlinePacker`**（上线通告？）和 **`COfflinePacker`**（离线上线/批量离线？）。它们很可能对应 §2.3/§2.4 里没能定名的命令号。**待验证**，但这是排查 1026/1027/1029–1032 的最佳线索。

另有两个模板族数量对不上：QGROUP 模板 13 条 vs 群组块桩 8 个、SHARE 模板 15 条 vs 共享块桩 8 个。说明这两块里**一个命令号承载多种变体**（请求/响应共用一个号），按 `RET`/`ERR` 字段区分方向。

---

## 4. TEA 密钥定位结果

| 项 | 值 |
|---|---|
| 密钥 | `8asfhj@k7*20hbla`（ASCII，仅 1 处） |
| 文件偏移 | `0x5EDDC8` |
| RVA | `0x5EF1C8` |
| VA（ImageBase 0x400000） | `0x9EF1C8` |

与规格里写的 `0x9ef1c8` **完全吻合**——规格那个地址是 VA，不是文件偏移。这一步同时验证了"提取脚本读到的字节偏移 → VA 换算"是正确的。

---

## 5. 方法说明与复现

### 5.1 脚本位置

全部是一次性脚本，放在仓库外：

```
.superpowers/sdd/nwt-private-protocol-reverse-engineering/scratch/
  extract-strings.mjs    字符串提取（ASCII + UTF-16LE）、PE 段表、TEA 密钥定位
  correlate.mjs          模板 → 命令号（±96 字节窗口投票）
  cmdscan.mjs            全量 imm32 + 跟随 call 的收敛点分析
  mapcmd.mjs             收敛点 → 模板（首版，窗口太小，仅作历史保留）
  mapcmd2.mjs            桩函数 → 调用者 → 模板（失败：构建函数之间无直接调用）
  mapcmd3.mjs / 4.mjs    反向：模板 → 所在函数 → 桩/发送 call（失败）
  mapcmd5.mjs            ★ 最终版：模板 → 后续 200 字节内的 push cmd
  peek.mjs / peek2.mjs   十六进制窗口查看
  out/                   全部中间产物
    ascii.txt / ascii-uniq.txt        74,747 条 ASCII 串
    utf16.txt / utf16-uniq.txt        2,155 条 UTF-16LE 串
    sections.txt                      PE 段表（imageBase=0x400000）
    tea-key.txt                       TEA 密钥命中
    xml-tags.txt                      模板里出现的标签计数
    templates.txt                     ★ 50 条 X_ 模板原文
    cmdscan.txt                       ★ 49 个发送桩 + 全部立即数
    cmd-to-template-final.txt / .json ★ 最终命令号 ↔ 模板映射
```

### 5.2 复现命令

```bash
cd D:/hllshiro/lanpost-im/.superpowers/sdd/nwt-private-protocol-reverse-engineering/scratch

# 1) 字符串提取 + 段表 + TEA 密钥
node extract-strings.mjs "D:/Program Files (x86)/nwt/Nwt/ShiYeLine.exe"

# 2) 找发送收敛点、列出 49 个命令号
node cmdscan.mjs "D:/Program Files (x86)/nwt/Nwt/ShiYeLine.exe"

# 3) 命令号 ↔ XML 模板
node mapcmd5.mjs "D:/Program Files (x86)/nwt/Nwt/ShiYeLine.exe"
```

Windows 无内置 `strings`，脚本用 `node:fs` 直接读字节，不依赖任何三方包。

### 5.3 关键技术点（给下一个人省时间）

1. **PE 段偏移换算**
   `.text` VA=0x1000 / RAW=0x400；`.rdata` VA=0x505000 / RAW=0x503c00；`imageBase=0x400000`。
   `VA = imageBase + section.VirtualAddress + (fileOffset - section.PointerToRawData)`。
   第一次搞反了 RVA 和 VA，浪费了一轮排查。

2. **字符串主体是 UTF-16LE，不是 ASCII**
   50 条模板里 35 条是宽字符串。只扫 ASCII 会漏掉 70%（第一次只找到 15 条）。

3. **别用 `/<X_/g` 配 `buf.toString('latin1')` 逐次 exec**
   会反复构造 7.4 MB 字符串；直接 `buf.indexOf(Buffer.from('<X_', enc))` 更快也更准。

4. **`while ((m = re.exec(s)))` 必须用带 `g` 的正则**
   第一版忘了 `g`，`exec` 永远返回同一个 match，死循环把 Node 堆打爆（4 GB OOM）。

5. **命令号的强证据是 `push imm32` + 紧邻 `call`**
   单纯扫 `1000..3999` 的 `u32` 完全不可用——`.rdata` 里的位图/查找表会产出成千上万个假阳性（本次原始命中 37,305 个，聚类后依然全是噪声）。

6. **构建函数之间没有直接调用**
   模板所在函数（`sprintf` 风格）与发送桩之间隔着 vtable/接口调用，所以"函数内找 call 桩"全部失败。真正管用的是**同一个函数体内、紧跟在 `sprintf` 之后的 `push cmd`**：

```asm
6a 01                 push 1                 ; docver
68 <fmtVA>            push "<X_XXX docver=..."> ; 模板
8d 44 24 xx           lea  eax,[esp+x]
68 00 10 00 00        push 0x1000            ; 4096 缓冲
50                    push eax
e8 ...                call sprintf 风格函数
...
68 e9 03 00 00        push 0x3e9             ; ← 1001，就是它
52 53                 push xml / push ctx
e8 ...                call 发送函数
```

7. **RTTI 没被裁剪**
   `.?AV<类名>@@` 形式的字符串完整保留，`*Packer` 类名可以直接当消息清单用，交叉验证模板是否找全。

---

## 6. 给 Phase 4（实时抓包）的靶标清单

优先级从高到低：

| 优先级 | 抓什么 | 怎么触发 | 期望看到 |
|---:|---|---|---|
| 1 | **1004 的 XML 明文结构** | 发一条含 emoji 和链接的消息 | 验证 `<MSG>` 里是 JSON、`MSG_ID` 是 `%llu`、`MSG_TIME` 是否真为 0 |
| 2 | **`TASK_ID` 的真实类型** | 发一个文件、发一个文件夹 | 文件 `%llu` / 文件夹 `%s` 是否成立——这是实现时的硬分流点 |
| 3 | **1010/1011 的 `OP` 取值** | 传输中点暂停/继续/取消 | `OP` 枚举值（决定状态机怎么接） |
| 4 | **1022/1023 的 `TYPE` 取值** | 让对方发离线消息（对方离线时发） | 离线三段的实际时序 |
| 5 | **1033–1043 群组块** | 建群、拉人、踢人、退群、解散 | 8 个命令号分别对应哪条 `X_QGROUP_*` |
| 6 | **1051–1058 共享块** | 打开对方的共享文件柜、进目录、输密码、下载 | 8 个命令号 ↔ 15 条 `X_SHARE_*` 的对应关系 |
| 7 | **1064 是不是远程协助** | 发起远程协助请求 | 是否为 `X_REMOTE_REQUEST` |
| 8 | **`COnlinePacker` / `COfflinePacker` 落在哪个号** | 上下线切换 | 可能是 1026/1027/1029–1032 中的两个 |
| 9 | **`<QGROUP_INFO_VER>` 的真实拼写** | 任意群组消息 | 确认模板里的 `</GROUP_INFO_VER>` 拼写 bug 是否真的出现在线上 |

抓包时建议直接对应用层的 u32 命令号做过滤（TEA 只加密正文，**命令号是明文**），比解 XML 快得多。

---

## 7. 明确未做的事

- 没有运行内网通，没有抓包，没有动态调试验证。
- 没有还原 9011 发现报文的准入字段（`0xa9` 起），本次只在字符串里看到 `<ShiYeLine docver="1"><SubnetIps>` 和 `%u@shiyeline:...` 两个线索。
- 没有定位 9012/9013/9014 TCP 文件通道的报文格式（`FILE_TRAN_TCP_PORT` 等字段说明端口由握手协商，但报文体未分析）。
- 没有反编译具体函数体，"§2.3" 里所有"猜测"都没有经过指令级验证。
