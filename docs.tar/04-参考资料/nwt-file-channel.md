# 内网通私有文件/文件夹二进制通道（9013/9014）帧格式

本文只描述**承载实际文件与文件夹字节的那条 TCP 通道**。XML 命令（`X_SEND_FILE`、`X_SEND_FOLDER`、`X_OPERATE_*`、`X_PROGRESS_RECV_FILE`、`X_REVERSE_*`）只负责通告与控制，字节走的是另一条 TCP 连接，本文给出这条连接的帧布局、命令字与握手时序。

> **⚠ 2026-11-12 真机抓包修正**（详见 [nwt-live-findings.md](nwt-live-findings.md)）：
> 1. **数据帧的 proto 字段：文件通道 = 1，文件夹通道 = 2**（本文曾写两者都为 2，以实测为准）。
> 2. **实际传输端口来自 `X_HANDSHARK` 的 `<NET>` 块，是随会话变化的动态端口**；9013/9014 只是本机默认监听/回退端口，不能写死。
> 3. 文件数据实测为 `unCmd 4`（文件夹数据为 `unCmd 5`）；`sChnnlId` 实测是 **UTF-16LE** 的 TASK_ID，不是 ANSI。
> 4. `X_OPERATE_*` 实测 `OP=2` 表示传输开始（暂停/取消值未触发）。

- 样本：内网通 3.4.3055，`D:/Program Files (x86)/nwt/Nwt/ShiYeLine.exe`（PE32 i386，ImageBase 0x400000）
- 方法：纯静态反汇编（Capstone），脚本在 `.superpowers/sdd/nwt-private-protocol-reverse-engineering/scratch/nnre.py`
- 未运行、未抓包。文中每个结论都标了置信度；标"中/低"的部分必须在真实抓包下确认（见 §8）

---

## 0. 结论先行

| 结论 | 置信度 |
|---|---|
| 文件通道 = TCP 9013（`CFileTranEngine`），文件夹通道 = TCP 9014（`CFolderTranEngine`），两者各自另有一个**临时端口监听器**（reverse） | 高 |
| 帧外壳：`u32 BE 总长(含自身) + u32 BE 协议号(2) + u32 BE unCmd + 20 字节保留(+0x0c..+0x1f) + 载荷`，长度**包含** 4 字节长度域 | 高 |
| 二进制通道**全程明文**，不经过 TEA/XTEA，也不做 MD5/SHA 校验 | 高 |
| 文件数据块 = `unCmd 5`，单帧载荷最大 32768 字节（0x8000） | 高 |
| 任务/通道标识 = 帧内 `sChnnlId`（300 字节定长字符串），值来自 `X_SEND_FILE`/`X_SEND_FOLDER` 的 `TASK_ID` | 高 |
| 接收方主动"要数据"（`unCmd 1`），文件持有方被动应答并推送（`unCmd 2/3/5`） | 中高 |
| `X_OPERATE_*` 的 `OP` 数值含义（暂停/继续/取消） | 低（未静态解出，见 §8.2） |
| 文件夹不是打包传输，而是"先发 635 字节/项的清单，再按项流式发送" | 中高 |

---

## 1. 端口从哪来

### 1.1 监听器创建点（静态确认）

| 创建函数 | 地址 | 监听端口 | 断言字符串 |
|---|---|---|---|
| `CNodeMsgMgr::Init` | `0x6506b0` | UDP 9012（ENet）+ UDP 0 + TCP **9012** + TCP 0 | `create ENetLsn failed` / `create ENetReverseLsn failed` / `create TcpLsn failed` |
| `CFileTranEngine::Init` | `0x644ac0` | TCP **9013** + TCP 0（reverse） | `create TcpLsn failed` / `create TcpReverseLsn failed` |
| `CFolderTranEngine::Init` | `0x6488f0` | TCP **9014** + TCP 0（reverse） | `create TcpLsn failed` / `create TcpReverseLsn failed` |

端口常量在机器码里是明文立即数：

```
00644b6a  push 0x2335            ; 9013
00644b6f  call dword ptr [0x90577c]  ; htons
00644b75  push eax
...
00644b82  call 0x5ab030          ; CreateTcpListener(parent, port)  → [engine+0xc]
00644bd8  call 0x5ab030          ; CreateTcpListener(parent, 0)     → [engine+0x10]  ← reverse
```

文件夹引擎同理：`push 0x2336`（9014）→ `[engine+0x28]`，`port 0` → `[engine+0x2c]`。
`0x2334 = 9012` 出现在 `CNodeMsgMgr::Init`。

### 1.2 与 `X_HANDSHARK <NET>` 的对应关系

`X_HANDSHARK` 的 `<NET>` 由 `0x667ca0` 附近的解析器读取，落点如下（`struct PeerNetInfo`）：

| XML 元素 | 落点偏移 | 实际含义 |
|---|---|---|
| `FILE_TRAN_TCP_PORT` | `peer+0x1f8` | 该对端的**文件** TCP 监听端口（默认 9013） |
| `FILE_TRAN_TCP_REVERSE_PORT` | `peer+0x1fc` | 该对端的**文件 reverse** 临时端口 |
| `FOLDER_TRAN_TCP_PORT` | 邻近字段 | 文件夹 TCP 监听端口（默认 9014） |
| `FOLDER_TRAN_TCP_REVERSE_PORT` | 邻近字段 | 文件夹 reverse 临时端口 |
| `*_ENET_PORT`、`*_ENET_REVERSE_PORT` | 同上簇 | 同一批业务的 ENet(UDP) 变体，本仓库不实现 |
| `LAN_UPDATE_HTTP_PORT` | 同上簇 | 内网升级 HTTP 服务，与文件通道无关 |

选择逻辑（`0x5befa4`，`CFileTran` 启动通道时）：

```c
if (peer->fileTcpPort != 0)                 // [peer+0x1f8]
    StartChannel(task, peer->fileTcpPort, /*flag=*/1, ip);
else if (peer->fileReverseTcpPort != 0)     // [peer+0x1fc]
    StartChannel(task, peer->fileReverseTcpPort, /*flag=*/0, ip);
```

`StartChannel`（`0x60cc30`）→ `0x645570`，`flag==0` 时走 `0x5ab240`（创建并 connect），`flag==1` 时走 `0x5ab100`（只创建 socket，不立即 connect）。**这一点是 §5 里唯一没完全闭合的环节**，需要抓包判定。

### 1.3 与实测监听端口对照

实测该机监听：`TCP 9012/9013/9014 + 62577..62579`。

- 9012 = `CNodeMsgMgr`（私有控制通道，见 `nwt-private-protocol.md`），不是文件通道；
- 9013 = 文件数据通道；9014 = 文件夹数据通道；
- 62577..62579 = 三个 `bind(0)` 的临时监听器：文件 reverse、文件夹 reverse、以及一个尚未定位的第三个（候选：`LAN_UPDATE_HTTP_PORT`，`X_HANDSHARK` 里它是 `%u` 而不是固定值）。**三个临时端口的具体归属需抓包确认**（§8.5）。

---

## 2. 帧外壳

### 2.1 布局（所有 `unCmd` 共用）

```
偏移  长度  类型        字段            说明                                  置信度
0x00   4   u32 BE      unLength        本帧总字节数，**包含这 4 字节自身**     高
0x04   4   u32 BE      unProto         固定 2（= 文件/文件夹数据通道）         高
0x08   4   u32 BE      unCmd           命令字（见 §3）                        高
0x0c   4   u32         -               保留 0                                 高
0x10   4   u32         -               保留 0                                 高
0x14   4   u32         -               保留 0                                 高
0x18   4   u32         -               保留 0                                 高
0x1c   4   u32         -               保留 0                                 高
0x20  300  char[300]   sChnnlId        任务通道标识（NUL 结尾，UTF-8/ANSI）    高
0x14c  ...             ...             按 unCmd 不同                       —
```

即：**先 0x20 字节定长头，再 300 字节的 `sChnnlId`，然后才是各 `unCmd` 自己的字段**。`unCmd 5`（数据块）的载荷从 **+0x36** 开始，所以它的头部只有 54 字节（0x36），没有用满 300 字节的 `sChnnlId`——数据帧用 `unItemIndex`（+0x20）取代了字符串通道标识。

> 字节序：长度、协议号、命令字与所有整数字段都是**大端**。代码里长度字段统一 `ntohl()` 后再做上限/下限校验：
> ```
> 0064b0b7  mov eax,[edi]        ; *(u32*)frame
> 0064b0e9  call 0x7076b2        ; ntohl
> 0064b0ef  cmp eax, 0x2ac       ; >= 最小帧长
> ```

### 2.2 接收侧解析（`CDataReceiverT<ISocket>::DoReceive`，`0x5a5f20`）

这是整条通道唯一的收帧函数，两个引擎共用（文件 9013 与文件夹 9014 都用它）。流程：

1. `recv(sock, stackBuf, 0x8000)` 到栈上 32 KiB 缓冲；
2. 状态 A（`[this+0x10] == 0`，还没有载荷缓冲）：把字节攒进 `[this+8..0xb]` 这 4 字节长度域，攒满后：
   ```c
   u32 len = bigEndian ? ntohl(hdr) : hdr;   // [this+0x1c] = 字节序开关，构造时置 1 = 大端
   if (len <= 8 || len > 0x80000) → 丢弃整帧并复位;   // 帧长必须 9..524288
   buf = malloc(len);
   *(u32*)buf = hdr;              // 长度域原样拷贝到帧首
   [this+0x10] = buf;             // 进入状态 B
   [this+0x14] = len;             // 本帧总长
   [this+0x18] = 4;               // 已有 4 字节
   ```
3. 状态 B：把剩余字节补进 `buf + have`，直到 `have == len`，把整帧指针交给上层链表，再全部复位。

**因此 `unLength` 含自身 4 字节，且一帧最小 9 字节、最大 512 KiB。**

### 2.3 发送侧（`CDataSenderT<ISocket>`，`0x5a63b0` / `0x5a64d0`）

- 上层 `malloc` 一整帧、填好首 4 字节长度后，`EnqueueFrame(ptr)`（`0x5a64d0`）挂到队列；
- `SendPending()`（`0x5a63b0`）每次取队首：`len = ntohl(*(u32*)buf)`，然后 `send(sock, buf+sent, len-sent)`，发完 `free`。
- **帧不是流式拼的**：每帧就是一个完整缓冲，长度域必须等于 `malloc` 的大小。
- 队列水位：发送方最多同时挂 **100 帧**（`cmp [sender+0x2c], 0x64`），超过就暂停读文件——这就是实际的流控。

### 2.4 与控制通道的对比（同一套外壳）

控制通道（`CMsgTran`，走 9012/ENet）用相同的 12 字节前缀，但 `unProto = 1`：

```
005aa624  push 0x158          ; 344
005aa629  call htonl          → [0x00] = 0x158
005aa632  push 1              → [0x04] = 1     ← 控制通道
005aa63c  push 1              → [0x08] = 1     ← unCmd
005aa694  ...                  [0x70..0x7f] = 16 字节 GUID
```

也就是说：`u32 长度 + u32 版本/类型 + u32 子类型 + 载荷` 这条旧笔记是对的，只是"版本/类型"实际是**通道类型**（1 = 控制，2 = 文件数据），"子类型"是 `unCmd`。

---

## 3. 命令字（unCmd）表

文件通道（9013，`CFileTran`）在 `0x64a070`（收方向）与 `0x64a450`（发方向）两个分发器里按 `unCmd` 分派。每个处理器都先校验"最小帧长"再校验"命令字"，所以下表的最小帧长是**代码里的立即数**，可直接当校验规则用。

| unCmd | 方向（谁发） | 固定/最小帧长 | 字段 | 含义 | 置信度 |
|---:|---|---|---|---|---|
| 1 | 接收方 → 文件持有方 | 固定 684 (0x2ac) | `sChnnlId`(+0x20) `unItemCount`(+0x278,u32) `unTotalItemSize`(+0x27c/+0x280,u64) | **请求开传**：我要这个通道的数据，共 N 项、总大小 S | 高 |
| 2 | 文件持有方 → 接收方 | 固定 672 (0x2a0) | `sChnnlId`(+0x20) | **接受**：通道就绪（回显通道号） | 高 |
| 3 | 文件持有方 → 接收方 | 0x4c + n×0x27b（最小 0x2c7 = 1 项） | `unItemCount`(+0x20) + n 条 635 字节清单项 | **文件清单**：逐项通告 名称/类型/序号/大小/时间 | 中高 |
| 4 | 接收方 → 文件持有方 | 0x4c + n×0x1a | `unItemCount`(+0x20) + n 条 26 字节进度项 | **进度同步/续传**：每项的 `unItemIndex`/`unItemOffset`/`unAction` | 中高 |
| 5 | 文件持有方 → 接收方 | 0x36 + n | `unItemIndex`(+0x20,u32) `unLength`(+0x24,u32) `unAction`(+0x28,u32) `payload`(+0x36) | **数据块**（正文） | 高 |
| 6 | 接收方 → 文件持有方 | 固定 58 (0x3a) | `unItemIndex`(+0x20) `unItemOffset`(+0x24/+0x28,u64) `unAction`(+0x2c) | **继续/回执**：下一块从 offset 开始 | 中高 |
| 7 | 文件持有方 → 接收方 | 固定 72 (0x48) | 无字段 | 对 6 的确认 | 中 |
| 8 | 接收方 → 文件持有方 | 固定 72 (0x48) | 无字段 | 对 7 的确认（本项收尾） | 中 |
| 100 (0x64) | 双向 | 1132 (0x46c) | `sChnnlId`(+0x20) | 任务级通知/中止（未解明） | 低 |

文件夹通道（9014，`CFolderTran`）是**另一套命令族**，处理器在 `0x6468xx`–`0x647xxx`，帧长与字段都和上表不同：

| unCmd | 最小帧长 | 已知字段 | 置信度 |
|---:|---|---|---|
| 1 | 500 (0x1f4) | `u64`(+0x34/+0x38)、wstring(+0x3c)、wstring(+0xa0) | 中 |
| 2 | ? | ? | 低 |
| 3 | ? | ? | 低 |
| 100 (0x64) | 560 (0x230) | ? | 低 |
| 108 (0x6c) | ? | ? | 低 |

> 说明：`0x647150` 的 `unCmd 1` 里两条 `std::wstring` 说明文件夹通道用的是 **UTF-16 路径**（与 9013 文件通道的 ANSI `sChnnlId` 不同），这一点与 `MAX_ITEM_PATH` 的宽度对得上。9014 的完整字段没有解完，抓包优先做它（§8.4）。

### 3.1 `unCmd 3` 的清单项（635 字节/项）

```
项内偏移  大小   字段              说明
0x000    600    aItemName         UTF-16LE 名称/相对路径，300 wchar，末尾必须为 0
0x256     2     -                 名称为空校验（`cmp word ptr [edi+0x256], 0`）
0x258     1     unItemType        1/2（文件/目录）
0x259     4     unItemIndex       BE，必须等于 期望序号（前面项数 + 起始序号）
0x25d     8     unItemSize        BE u64（lo 在 0x25d，hi 在 0x261）
0x265     8     -                 BE u64（另一尺寸，疑似累计/目录总大小）
0x26d     4     -                 BE u32（疑似 unLastModify）
0x271    10     -                 保留
总长 0x27b = 635
```

错误字符串直接泄了字段名：`aItemName error`(0x9e90fc)、`unItemType error`(0x9e911c)、`unItemIndex error`(0x9e9140)、`unItemCount error`(0x9e9010)、`unTotalItemSize error`(0x9e9034)、`unItemOffset error`(0x9e919c)、`unAction error`(0x9e91c4)、`sChnnlId error`(0x9e8ff0)、`unCmd error`(0x9e8fd8)、`unLength error`(0x9e8fb8)。

### 3.2 `unCmd 4` 的进度项（26 字节/项）

```
项内偏移  大小  字段
0x00      4    unItemIndex   BE
0x04      8    unItemOffset  BE u64（已收/已发字节数，续传起点）
0x0c      4    unAction      BE（0 = RecvDataOk，1 = RecvDataSkip）
0x10     10    保留
```

对应错误串 `RecvDataOk error`(0x9e91e4)、`RecvDataSkip error`(0x9e9208)。`unAction` 0/1 的语义就是"这一项正常接收 / 这一项跳过"。

---

## 4. 分块、校验、续传

- **分块大小**：文件持有方每次 `ReadFile` 读 **0x8000 = 32768 字节**（`0x64d330: push 0x8000`），一帧一个块，帧长 = 0x36 + n。接收侧 `DoReceive` 的 `recv` 缓冲也是 0x8000，单帧上限 0x80000。
- **发送窗口**：每任务最多 100 帧在途（约 3.2 MiB），由发送队列水位控制，不是滑动窗口。
- **校验**：
  - 只有长度与结构校验（`unLength` 上下限、`unCmd`、`sChnnlId`、`unItemIndex`、`unItemOffset` 连续性与 item 大小比较）；
  - **没有 MD5/SHA**：CRYPT32/ADVAPI32 的哈希 API 在整个 `0x64xxxx`（文件引擎）与 `0x5axxxx`（收发模板）区间没有任何调用点；
  - 也没有 CRC。真正的完整性依赖 TCP 与"每项大小必须累计相等"这一条（`0x64d4c0` 里 `已写 + 本块 <= 项大小`）。
- **加密**：明文。TEA/XTEA 的所有调用点集中在 `0x65xxxx`–`0x67b47f`（XML 命令的打包/解包），`0x64xxxx` 数据引擎与 `0x5axxxx` 收发模板里**一次都没有**。旧笔记"私有文件通道是明文"成立。
- **续传**：
  - 接收方按项存储 `unItemOffset`（task 内 `[item+0x48]/[item+0x4c]`，u64）；
  - 用 `unCmd 4` 批量把 (index, offset, action) 回送持有方；
  - 持有方据此决定"从头读"还是"跳读"（`0x64d120` 走 `SetFilePointerEx` 再发 `unCmd 5`）；
  - 断线重连后任务仍按 `TASK_ID` 存活，重新走 `unCmd 1`。
- **暂停/取消**：走控制面 XML（`X_OPERATE_SEND_FILE` / `X_OPERATE_RECV_FILE` 的 `OP`），数据面没有独立的 pause 帧；`unCmd 100` 疑似任务级中止通知（低置信度）。

---

## 5. 连接与时序

### 5.1 普通发文件（TCP 9013）

```
A（发送方，监听 9013）                         B（接收方）
  |-- X_SEND_FILE: TASK_ID=1747... , SIZE=... -->|   （控制通道，TEA XML）
  |<-- X_OPERATE_RECV_FILE: TASK_ID, OP=accept --|
  |                                              |
  |<========= TCP connect → A:9013 ==============|   谁连谁见 §5.4
  |<-- unCmd 1  sChnnlId=TASK_ID, count, size ---|
  |--- unCmd 2  sChnnlId=TASK_ID --------------->|
  |--- unCmd 5  itemIndex, len=32768, action=0 ->|   循环，最多 100 帧在途
  |--- unCmd 5  ... ---------------------------->|
  |<-- unCmd 6  itemIndex, offset(u64), action --|
  |--- unCmd 7  -------------------------------->|
  |<-- unCmd 8  --------------------------------|
  |              （全部项完成）                   |
  |<-- X_PROGRESS_RECV_FILE（控制通道，周期性）    |
```

要点：
- `sChnnlId` = `X_SEND_FILE` 的 `TASK_ID`（`%llu`）的十进制字符串；`unCmd 1` 到达时持有方用它去任务表里找回 `CFileTran`（`0x64b133` 是字符串比对，失败打印 `sChnnlId error`）。
- 一个 TCP 连接承载**一个任务**；任务内所有项（文件夹时成百上千个文件）在同一条连接上顺序流式发送。
- `unCmd 6/7/8` 是"继续—确认—再确认"的三段握手，粒度是**项**而不是块（块靠 100 帧窗口 + TCP 背压）。

### 5.2 发文件夹（9014 为主，9013 内部也带清单能力）

```
A（发送方）                                    B（接收方）
  |-- X_SEND_FOLDER: TASK_ID(字符串), FOLDER_NAME,
  |    FOLDER_SIZE, MAX_ITEM_PATH, MAX_ITEM_SIZE, OFFLINE -->
  |<-- X_OPERATE_RECV_FOLDER: TASK_ID, OP=accept ------|
  |<=========== TCP connect → A:9014 =================|
  |<-- unCmd 1（文件夹族, 500 字节）-------------------|
  |--- unCmd 2/3（清单/就绪）------------------------->|
  |    按项循环：unCmd 5 数据块 + unCmd 6/7/8 续传握手  |
```

- `MAX_ITEM_PATH` / `MAX_ITEM_SIZE` 不是事后校验，而是**发送端扫描目录时的准入上限**（超过就整单拒绝或跳过），并在协议里体现为清单项的固定宽度：
  - 名称/相对路径字段固定 **600 字节 = 300 个 wchar**（`0x27b` 项的前 0x258 字节）；
  - 每项大小是 u64，理论无 4 GiB 限制，受 `MAX_ITEM_SIZE` 约束。
- 文件夹**不打包**：没有 zip/tar，接收方逐项 `CreateFile`/`WriteFile`（`0x64d4c0` 直接 `WriteFile`），因此中途取消会留下半成品文件。

### 5.3 反向（拉取）

`X_REVERSE_FILE_REQ` / `X_REVERSE_FOLDER_REQ` 只带 `TASK_ID`，它表示"请把这条传输反向启动"。真正的差别在端口选择：

- `FILE_TRAN_TCP_PORT`（9013）：该对端作为**被动方**的文件服务端口；
- `FILE_TRAN_TCP_REVERSE_PORT`（临时端口）：该对端作为**主动连接方**时使用的端口。

`0x5befa4` 的兜底逻辑说明了两者互斥：对端的普通文件端口为 0 时才用 reverse 端口，并且 `StartChannel` 的 `flag` 从 1 变 0（从"不立即 connect"变成"create+connect"）。所以 reverse 的语义是**把 TCP 连接方向反过来**：不是"接收方连发送方"，而是"文件持有方连到请求方的 reverse 端口"。

> 置信度：中。`flag` 与哪一侧是主动连接方，静态上已看到两条互斥路径，但没有把 `0x5ab100`（不 connect）之后由谁触发 connect 完全串起来，必须靠抓包定案（§8.1/§8.3）。

### 5.4 谁 CONNECT 谁（当前最佳解释）

| 场景 | 连接发起方 | 目标端口 | 数据方向 |
|---|---|---|---|
| A 发文件给 B（普通） | B（接收方） | A 的 `FILE_TRAN_TCP_PORT` = 9013 | A→B 推，B 用 `unCmd 1/6` 拉 |
| A 发文件给 B（对端普通端口为 0） | A（持有方） | B 的 `FILE_TRAN_TCP_REVERSE_PORT` | 同上 |
| 反向拉取（`X_REVERSE_FILE_REQ`） | 文件持有方 | 请求方的 reverse 端口 | 同上（角色不变，只换连接方向） |
| 文件夹 | 同上，端口换 9014 / folder reverse | | |

理由：`unCmd 1`（"给我数据"）由状态 2 的拉取侧发出（`0x64a450` 的状态机 `case 2` → `0x655ad0` 构造 `unCmd 1`），而 `unCmd 1` 的处理器（`0x64b030`）在**持有方**打开文件并启动 `unCmd 5` 泵（`0x64d060`）。

---

## 6. 文件夹传输与 `X_SEND_FOLDER` 的对应

| XML 字段 | 在数据面的落点 |
|---|---|
| `TASK_ID`（**字符串**） | `sChnnlId`（300 字节，与文件任务的区别就在类型） |
| `FOLDER_NAME` | `unCmd 3` 首项的 `aItemName` |
| `FOLDER_SIZE` | `unCmd 1` 的 `unTotalItemSize`（u64） |
| `MAX_ITEM_PATH` | 清单项名称字段宽度上限（600 字节 / 300 wchar）+ 扫描期过滤 |
| `MAX_ITEM_SIZE` | 清单项 `unItemSize` 上限（u64），扫描期过滤 |
| `OFFLINE` | 只影响离线队列，不影响帧格式 |

`X_PROGRESS_RECV_FILE`（`TOTAL_SIZE` / `RECVD_SIZE` / `SPEED`）由 `0x64dd60` 在写盘后触发，属于控制面进度上报，接收方每完成一个块/项更新一次。

---

## 7. 关键函数索引（便于二次验证）

| 地址 | 名称/作用 |
|---|---|
| `0x6506b0` | `CNodeMsgMgr::Init`（9012 控制通道，ENet+TCP） |
| `0x644ac0` | `CFileTranEngine::Init`（9013 + reverse） |
| `0x6488f0` | `CFolderTranEngine::Init`（9014 + reverse） |
| `0x667ca0` | `X_HANDSHARK` 解析（`<NET>` → `peer+0x1f8/0x1fc`…） |
| `0x60cc30` | `CFileTran::StartChannel` → `0x645570` |
| `0x5a5f20` | `CDataReceiverT::DoReceive`（收帧，长度域解析在此） |
| `0x5a63b0` / `0x5a64d0` | `CDataSenderT::SendPending` / `EnqueueFrame` |
| `0x656010` | 构造 `unCmd 5` 数据帧（`0x36 + n`） |
| `0x6560a0` | 构造 `unCmd 6`（58 字节） |
| `0x656120` / `0x656170` / `0x6561c0` | 构造 `unCmd 7` / `8` / `100` |
| `0x655ad0` / `0x655b90` / `0x655c00` | 构造 `unCmd 1` / `2` / `3` |
| `0x64a330`/`0x64a070`/`0x64a450`/`0x6497f0` | 每任务状态机与 `unCmd` 分发 |
| `0x64b030`…`0x64c6d0` | `unCmd 1/2/3/4/5/6/7/8` 处理器 |
| `0x64d2f0` | 读文件 → `unCmd 5` 泵（`ReadFile 0x8000`） |
| `0x64d4c0` | 收数据 → `WriteFile`（含项大小校验） |
| `0x5ab030` / `0x5ab100` / `0x5ab240` | 建监听 socket / 建未连接 socket / 建并 connect |

---

## 8. 必须抓包确认的点（直接照做即可）

前提：两台机器各跑一个内网通（或在同一台机用两个数据目录 + 不同端口），Wireshark 过滤 `tcp.port == 9013 || tcp.port == 9014`，并把 9011 上的 `X_HANDSHARK`（TEA 明文解密后）一起导出。

1. **谁 CONNECT 谁 + 首帧内容**（最重要）
   发一个 20 MiB 文件，抓两端。确认：
   - SYN 的方向与目标端口（9013 还是 6257x 的 reverse 端口）；
   - 首帧十六进制应为 `00 00 02 ac | 00 00 00 02 | 00 00 00 01 | 24×00 | <TASK_ID 字符串>`；
   - 该字符串是否等于 `X_SEND_FILE` 的 `TASK_ID`；
   - 第 4–8 字节是否恒为 `00 00 00 02`。
2. **`OP` 枚举**（静态未解出）
   传输中依次点"暂停 / 继续 / 取消"，在控制面记录 `X_OPERATE_SEND_FILE`、`X_OPERATE_RECV_FILE`（文件夹对应 `X_OPERATE_*_FOLDER`）里的 `<OP>` 数值，并与 `unCmd 6` 的 `unAction` 对比 → 得到 OP 的完整枚举。
3. **块大小与窗口**
   让文件 > 100 MiB，统计 `unCmd 5` 的 `unLength` 分布：期望 `0x36 + 0x8000 = 32822`，末尾块更短；同时看未 ACK 在途帧数是否止步于 100 → 验证窗口上限。
4. **文件夹清单（9014）**
   发一个含中文名/深层路径/大文件的目录，抓 9014 首包，确认：
   - `unCmd 1` 的 500 字节帧里两个 wstring 的实际含义（源路径 / 目标路径？）；
   - `unCmd 3` 清单项是否 635 字节、`unItemType` 的 1/2 分别对应文件还是目录、`+0x271` 起的 10 字节是否为 `unLastModify`；
   - 中文路径是 UTF-16 还是带 BOM 的变体。
5. **三个临时端口的归属**
   在两端分别 `netstat -ano` 对照 `X_HANDSHARK` 里上报的 `FILE_TRAN_TCP_REVERSE_PORT`、`FOLDER_TRAN_TCP_REVERSE_PORT`、`LAN_UPDATE_HTTP_PORT`，确认 62577/62578/62579 的映射关系（预期前两个是 reverse，第三个是 HTTP）。
6. **`unCmd 100` 与取消后的收尾**
   传输中途拔网线/点取消，看是否出现 `unCmd 100`（1132 字节）或直接 RST；确认半成品文件是否保留。
7. **`X_REVERSE_FILE_REQ` 的真实端口**
   在共享文件柜/离线文件里触发一次"拉取"，抓包确认发起方连的是对方的 9013 还是对方的 reverse 临时端口 —— 这条直接判定 §5.4 的表。

---

## 9. 已知限制 / 未解部分

- `unCmd 7/8` 的业务含义只到"对 6 的确认 / 对 7 的确认"这一层，为什么需要三段而不是两段，静态看不出（可能与"每项完成的落盘 + 进度上报"有关）。
- `unCmd 1` 帧固定 684 字节，但构造器只写到 `+0x280`，尾部 40 字节恒 0；是否还有未使用的字段（如断点续传的"已完成项数"）需要抓包对比。
- 9014 文件夹通道的命令族只确认了 `unCmd` 值（1/2/3/100/108）和两个最小帧长（500/560），字段表未解完。
- 数据面没有加密也没有摘要，因此**不具备防篡改能力**；这是协议本身的性质，不是分析遗漏。
